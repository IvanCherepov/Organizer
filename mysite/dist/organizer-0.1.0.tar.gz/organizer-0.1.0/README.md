# Organizer

This is a simple organizer for your bookmarks.

## Installation

## Technologies
Python and Django.

## Description
giUsers can create lists (of links), edit lists, add links, edit and delete 
links and tag them!
