# Organizer
Organizer for your Bookmarks

Python and Django

Users can create lists (of links), edit lists, add links, edit and delete links and tag them!
